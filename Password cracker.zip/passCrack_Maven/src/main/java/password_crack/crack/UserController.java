package password_crack.crack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

@RestController
@RequestMapping("/api")

public class UserController{
	private PasswordStorage storage;

	@Autowired
	public UserController(PasswordStorage storage){
		this.storage = storage;
	}

	@PostMapping(value = "/addUser")
	public RedirectView addUser(@RequestParam("personUsername") String username,
                        @RequestParam("personPassword") String password,
						RedirectAttributes model)
    {
        if(!storage.containsUsername(username)){
			storage.AddClient(username, password);
			List<Client> users = storage.getUsers();
			model.addFlashAttribute("quantity", storage.getElementsQuantity());
			model.addFlashAttribute("username", username);
			model.addFlashAttribute("password", password);
			model.addFlashAttribute("salt", storage.getUserInfo(username)[0]);
			model.addFlashAttribute("hash", storage.getUserInfo(username)[1]);
            model.addFlashAttribute("users", users);
			return new RedirectView("/");
        }

		List<Client> users = storage.getUsers();
		model.addFlashAttribute("quantity", storage.getElementsQuantity());
		model.addFlashAttribute("users", users);
        return new RedirectView("/"); 
	}

	@PostMapping("/clearUsers")
	public RedirectView clearUsers(Model model){
		storage.deleteUsers();
		List<Client> users = storage.getUsers();

		model.addAttribute("users", users);
		return new RedirectView("/");
	}
	private int nr = 0;
	@PostMapping("/attackSingle")
	public ResponseEntity<Map<String, Object>> attackSingle(@RequestBody Map<String, String> request){
		String username = request.get("username");
		String password = request.get("password");

		Map<String, Object> response = new HashMap<>();
		boolean match = false;

		if(storage.containsUsername(username)){
			String[] salt_hashedPass = storage.getUserInfo(username);
			Client client = new Client(password, storage.getBitsQ(), storage.getSaltLength());
			Hashing hash = new Hashing(client.getNumbers(), storage.getBitsQ(), password, storage.getSaltLength());
			
			match = hash.checkPassword(salt_hashedPass[0], salt_hashedPass[1]);
			response.put("success", match);
			response.put("message", (match) ? "Correct password" : "Incorrect password");
			System.out.printf("%s\t%s\n",nr++, response);
			if( match == true ){return ResponseEntity.ok(response);}
			return ResponseEntity.ofNullable(response);
		}

		response.put("success", false);
		response.put("message", "Incorrect password");
		System.out.printf("\n\n%s\t%s\n\n",nr++, response);
		return ResponseEntity.ofNullable(response);
	}
	@GetMapping(value = "/addUser")
	public String addUser(){
		return "index";
	}
}
