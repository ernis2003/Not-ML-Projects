package password_crack.crack;

class Client{
    //This class taking an input password of client and quantity of encryption bits quantity
    //and by using encryptor class and passing charsOfNumbers and bits_Q, get's encrypted password
    private String inputPass;
    private String username;
    private String encryptedPass;
    private String salt;
    private int bitKeys_Q;
    private int saltLength;
    
    private final char[] specialSymbols = new char[] {
        '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', 
        ':', ';', '<', '=', '>', '?', '@', 
        '[', '\\', ']', '^', '_', '`', 
        '{', '|', '}', '~'
    };

    public Client(String inputPass, int bitKeys_Q, int saltLength){
        this.inputPass = inputPass;
        this.bitKeys_Q = bitKeys_Q;
        this.saltLength = saltLength;
    }
    public Client(String username, String inputPass, String salt, String encryptedPass){
        this.username = username;
        this.inputPass = inputPass;
        this.salt = salt;
        this.encryptedPass = encryptedPass;
    }

    //Methods
    public int[] getNumbers() throws IllegalArgumentException{ //small letters (0-25) -> numbers (26-35) -> big letters (36-61) -> special symbols (62-93)
        char[] charsArr = inputPass.toCharArray();
        int[] finalArr = new int[charsArr.length];
        /*System.out.printf("First: %s\nSecond: %s\nThird: %s\nFourth: %s\n",
                            new char[] {':', ';', '<', '=', '>', '?', '@'}.length,
                            new char[] {'[', '\\', ']', '^', '_', '`'}.length,
                            new char[] {'{', '|', '}', '~'}.length,
                            new char[] {'!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/'}.length);*/

        for(int i = 0; i < charsArr.length; i++){
            if (Character.isDigit(charsArr[i])) {
                finalArr[i] = charsArr[i] - '0' + 26; //converting char into number ASCII
            }
            else if (containsSpecial(charsArr[i])) {
                int differenceVal = charsArr[i] - '!';
                if (differenceVal >= 25 && differenceVal <= 31) { //':', ';', '<', '=', '>', '?', '@' (77 - 83)
                    finalArr[i] = differenceVal + 52;
                }
                else if (differenceVal >= 58 && differenceVal <= 63) { //'[', '\\', ']', '^', '_', '`' (84 - 89)
                    finalArr[i] = differenceVal + 26;
                }
                else if(differenceVal >= 90 && differenceVal <= 93){ //'{', '|', '}', '~' (90 - 93)
                    finalArr[i] = differenceVal;
                }
                else if(differenceVal < 15){ // '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/' (62 - 76)
                    finalArr[i] = differenceVal + 62;
                }
            }
            else if(Character.isLetter(charsArr[i])){ //If letter
                if (Character.isLowerCase(charsArr[i])) { //Lowercase
                    finalArr[i] = charsArr[i] - 'a';
                }
                else if(Character.isUpperCase(charsArr[i])){ //Uppercase
                    finalArr[i] = charsArr[i] - 'A' + 36;
                }
            }
            else{
                System.out.println("Neteisingas simbolis: '" + charsArr[i] + "'");
                throw new IllegalArgumentException("Incorrect symbol detected!");
            }
        }
        return finalArr;
    }

    public boolean containsSpecial(char symbolToCheck){
        for (int i = 0; i < specialSymbols.length; i++) {
            if(specialSymbols[i] == symbolToCheck){return true;}
        }
        return false;
    }
    public int getBitQ(){
        return bitKeys_Q;
    }
    public String getPassword(){
        return inputPass;
    }
    public String getUsername(){
        return username;
    }
    public String getSalt(){
        return salt;
    }
    public String getHash(){
        return encryptedPass;
    }
    public int getSaltLength(){
        return saltLength;
    }
}