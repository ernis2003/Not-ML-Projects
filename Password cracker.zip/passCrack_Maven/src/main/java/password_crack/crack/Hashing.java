package password_crack.crack;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;


class Hashing{
    private String originalPassword; //It can be removable
    private String[] binaryNumbers;
    private int[] charNumbersArr;
    private int bitKeys_Q;
    private int saltLength;

    //Hashing -> one way encoding
    //Encryptor -> two way encoding

    public Hashing(int[] charNumbersArr, int bitKeys_Q, String originalPassword, int saltLength){
        this.originalPassword = originalPassword;
        this.charNumbersArr = charNumbersArr;
        this.bitKeys_Q = bitKeys_Q;
        this.binaryNumbers = new String[charNumbersArr.length];
        this.saltLength = saltLength;
    }
    
    public String convertToBinary() throws ArithmeticException{
        String binarySequence = "";
        for(int i = 0; i < charNumbersArr.length; i++){
            String binarySeq = getBinary(charNumbersArr[i]).toString();
            if (binarySeq.length() < bitKeys_Q) { //If not enough symbols
                String zeros = new String(new char[bitKeys_Q - binarySeq.length()]).replace("\0", "0");
                binarySeq = zeros + binarySeq;
            }
            else if(binarySeq.length() > bitKeys_Q){
                throw  new ArithmeticException("Bits quantity is too small for hashing these numbers");
            }
            binaryNumbers[i] = binarySeq;
            binarySequence += binarySeq;
        }
        return binarySequence;
    }
    public StringBuilder getBinary(int intSeqNumber){
        StringBuilder valueRemain = new StringBuilder();
        if(intSeqNumber == 0){
            for(int i = 0; i < bitKeys_Q; i++) {valueRemain.append('0');}
            return valueRemain.reverse();
        }
            int value = intSeqNumber;
            while (value > 0) { 
                valueRemain.append(String.valueOf(value % 2));
                value = value / 2;
            }
        return valueRemain.reverse();
    }
    
    public String[] getBinary(int[] intSeqNumber){
        String[] builderArr = new String[intSeqNumber.length];
        for(int i = 0; i < intSeqNumber.length; i++){
            StringBuilder valueRemain = new StringBuilder();
            if(intSeqNumber[i] == 0){
                for(int j = 0; j < bitKeys_Q; j++) {valueRemain.append('0');}
                builderArr[i] = valueRemain.reverse().toString();
                return builderArr;
            }

            int value = intSeqNumber[i];
            while (value > 0) { 
                valueRemain.append(String.valueOf(value % 2));
                value = value / 2;
            }
            builderArr[i] = valueRemain.reverse().toString();
        }
        return builderArr;
    }

    public String GenerateSalt(){
        String finalSalt = "";
        while(finalSalt.length() != saltLength){
            int value = (int) Math.round(Math.random() * 122); // (33 - 122), ASCII values chars + spec symbols
            if (value >= 33 && value <= 122) {
                finalSalt += (char) value;
            }
        }
        return finalSalt;
    }
    public String[] Hash(){
        convertToBinary();
        String salt = GenerateSalt();
        String[] encryptedBits = EncryptBits();     
        String hashedPassword = HashPassword(salt, String.join("", encryptedBits));
        System.out.printf("Original password: %s\tHashed password: %s (%s length)\n",originalPassword, hashedPassword, hashedPassword.length());
        return new String[] {salt, hashedPassword, originalPassword};
    }

    public String HashPassword(String salt, String hashedBits) throws IllegalArgumentException{ //salt + bits_Q = hash_pass.length
        if(salt.length() > bitKeys_Q || salt.length() <= 0) {throw new IllegalArgumentException("Salt length must less (more than 0) or equal to bits_Q"); }
        
        char[] charArr = hashedBits.toCharArray();
        char[] saltArr = salt.toCharArray();
        String hashedPass = "";

        hashedPass += salt.substring(0, salt.length() / 2);
        int saltIterator = 0;
        for(int i = 0; i < charArr.length / 2; i++){
            if(saltIterator > 0){
                if(i % saltIterator == 0 && (i / saltIterator) * saltIterator == i && saltIterator == saltArr.length)
                { saltIterator = 0; }
            }
            if (charArr[i] == '1') {
                hashedPass += String.valueOf(charArr[i]) + String.valueOf(saltArr[saltIterator]);
            }
            else{
                hashedPass += String.valueOf(charArr[i]) + String.valueOf(salt.substring(saltIterator, saltIterator+1));
            }
            saltIterator++;
        }
        hashedPass += salt.substring(salt.length()/2, salt.length());
        return hashedPass;
    }
    
    /*
     * Encrypted - it's possible to decrypt using key.
     * Replace bits from start to end.
     */
    public String[] EncryptBits(){
        String[] encryptedBitNumbers = new String[binaryNumbers.length];

        for(int i = 0; i < binaryNumbers.length; i++){
            String currentBits = binaryNumbers[i];
            String encryptedString = "";
            
            if (currentBits.length() % 4 == 0 || (currentBits.length() % 4 != 0 && currentBits.length() % 2 == 0)) {
                StringBuilder builder = new StringBuilder();
                builder.append(currentBits);
                encryptedString = builder.reverse().toString();
            }
            else{ //If binary_length % 2 != 0
                String firstPartBits = currentBits.substring(0, (currentBits.length() - 3) / 2); //3 bitus paliekame vietoje, bet sukeiciame bitŲ seką
                String secondPartBits = currentBits.substring((currentBits.length() + 3) / 2, currentBits.length());
                
                StringBuilder builder = new StringBuilder();
                builder.append(currentBits.substring((currentBits.length() - 3) / 2, (currentBits.length() + 3) / 2));
                encryptedString = secondPartBits + builder.reverse().toString() + firstPartBits;
            }
            encryptedBitNumbers[i] = encryptedString;
        }
        return encryptedBitNumbers;
    }

    /*
     * Return true if input password bits matches with existing keys (then password exist)
     * Otherwise - false  
     */
    public boolean checkPassword(String salt, String hashPassToCompare){
        convertToBinary();
        String[] encryptedBits = EncryptBits();     
        String hashedPassCalculated = HashPassword(salt, String.join("", encryptedBits));
        if(hashedPassCalculated.equals(hashPassToCompare)){return true;}
        return false;
    } 

    public void PrintAllData(int[] charNumbers, String[] originalBinary, String[] encryptedBinary, String title){
        System.out.println(title);
        System.out.printf("\n\nORIGINAL PASSWORD:\t%s", originalPassword);
        for(int i = 0; i < binaryNumbers.length; i++){
            System.out.printf("\n%s)\tNumber code:\t%s\t->\tOriginal binary:\t%s\t->\tEncrypted binary:\t%s", i+1, charNumbers[i], originalBinary[i], encryptedBinary[i]);
        }
    }
}
class PasswordStorage{
    private static int bits_Q;
    private static int saltLength;
    private int elementsQuantity;
    private HashMap<String, String[]> passStorage; //Key - username, String[salt, hashcode]
    private String[] allSalts;
    private int allSaltsIterator;
    /*
     * Store:
     * - Username
     * - Salt
     * - Hash
     */

    public PasswordStorage(int bits_Q, int saltLength){
        HashMap<String, String[]> map = new HashMap<>();
        this.bits_Q = bits_Q;
        this.saltLength = saltLength;
        this.passStorage = map;
        this.elementsQuantity = 0;
        this.allSalts = new String[100];
        this.allSaltsIterator = 0;
    }

    public String[] AddClient(String username, String password) throws IllegalArgumentException{
        Client client = new Client(password, bits_Q, saltLength);
        Hashing hashClass = new Hashing(client.getNumbers(), bits_Q, password, saltLength);

        String[] saltHashedPass = hashClass.Hash();
        while (containsSameSalt(saltHashedPass[0])) { 
            saltHashedPass = hashClass.Hash();
        }
        
        passStorage.put(username, new String[]{saltHashedPass[0], saltHashedPass[1], saltHashedPass[2]});
        allSalts[allSaltsIterator++] = saltHashedPass[0];
        elementsQuantity++;
        return new String[] {saltHashedPass[1], client.getUsername()};
    }

    public boolean containsUsername(String username){
        return passStorage.containsKey(username);
    }
    /*
     * Returning salt and hashed password
     */
    public String[] getUserInfo(String username){
        return passStorage.get(username);
    }

    /*
    * Checking, does generated salt already exist
    */
    public boolean containsSameSalt(String saltToCheck){
        for(String value : allSalts){
            if (saltToCheck.equals(value)) {
                return true;
            }}
        return false;
    }
    /*
    * Returning elements quantity in table
    */
    public int getElementsQuantity(){
        return elementsQuantity;
    }
    
    /*
     * Returning iterable object to iterate throw them in html
     */
    public List<Client> getUsers(){
        Set<String> keySet = passStorage.keySet();
        List<Client> clients = new ArrayList<>();
        for(String username : keySet){
            clients.add(new Client(username, passStorage.get(username)[2], passStorage.get(username)[0], passStorage.get(username)[1]));
        }
        return clients;
    }

    /*
     * Delete all users from table
     */
    public void deleteUsers(){
        passStorage.clear();
        elementsQuantity = 0;
    }
    public int getSaltLength(){
        return saltLength;
    }
    public int getBitsQ(){
        return bits_Q;
    }
}
