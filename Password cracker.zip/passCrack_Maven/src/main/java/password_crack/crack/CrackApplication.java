package password_crack.crack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@SpringBootApplication
public class CrackApplication {
	private static final int bits_Q = 64;
	private static final int saltLength = 16;

	public static void main(String[] args) {
		SpringApplication.run(CrackApplication.class, args);

	}
	
	@Bean
	public PasswordStorage getStorage(){
		PasswordStorage storage = new PasswordStorage(bits_Q, saltLength);
		
		String[] passwords = new String[] {"1", "1", "1"};

        for(int i = 0; i < passwords.length; i++){
            Client client = new Client(passwords[i], bits_Q, saltLength);
            Hashing enc = new Hashing(client.getNumbers(), bits_Q,
                                        client.getPassword(), saltLength);
            enc.Hash();
        }

		return storage;
	}

	@GetMapping("/")
	public String home(Model model){
		return "index";
	}
}
