const stopAttackId = `stopAttackAll`;
const attackAllId = `attackAutoBtn`;
const attackSingleId = `attackBtn`;
const usernameInput = `username`;
const passwordInput = `password`;
const attacksQId = `attacksQuantity`;
const addUserId = `addUserBtn`;
const resetAllId = `resetAll`;
const allAttacksLabel = `attackListQuantity`;
const successAttacksLabel = `successAttacks`;
const attackTableId = `allAttacksList`;

const sprayAttackId = `sprayAttack`;
const bruteForceId = `bruteForce`;
const dictionaryId = `dictionaryAttack`;
const inputUsernameLabel = `usernameToAttack`;

let isAttacking = false;
var counterElement = null;
//Must be the same as in index.html file

document.addEventListener("DOMContentLoaded", function(){
    //const
    const attackAllBtn = document.querySelector(`button[id='${attackAllId}']`);
    const attackSingleBtn = document.querySelector(`button[id='${attackSingleId}']`);
    const usernameField = document.querySelector(`input[id='${usernameInput}']`);
    const passwordField = document.querySelector(`input[id='${passwordInput}']`);
    const attacksQuantity = document.querySelector(`h1[id='${attacksQId}']`);
    const resetAllBtn = document.querySelector(`button[id='${resetAllId}']`);
    const attackListLabel = document.querySelector(`label[id='${allAttacksLabel}']`);
    const attackTable = document.querySelector(`tbody[id='${attackTableId}']`);
    const addUserBtn = document.querySelector(`button[id='${addUserId}']`);
    const successAttackLabel = document.querySelector(`b[id='${successAttacksLabel}']`);

    //AttackBtns
    const sprayAttack = document.querySelector(`input[id='${sprayAttackId}']`);
    const bruteForce = document.querySelector(`input[id='${bruteForceId}']`);
    const dictionary = document.querySelector(`input[id='${dictionaryId}']`);
    const usernameLabelAttack = document.querySelector(`input[id='${inputUsernameLabel}']`);

    var checkedPass = {};
    
    //Other data manipulation
    var attacksQ = localStorage.getItem("attacksQ");
    var successAttacks = localStorage.getItem("successAttack");
    if(attacksQ){
        attacksQuantity.innerHTML = attacksQ;
        attackListLabel.innerHTML = attacksQ;
        successAttackLabel.innerHTML = successAttacks;
    }


    //event listeners
    bruteForce.addEventListener('click', function(event){
        hideUsername(event);
    });
    dictionary.addEventListener('click', function(event){
        hideUsername(event);
    });
    sprayAttack.addEventListener('click', function(event){
        hideUsername(event);
    });

    attackAllBtn.addEventListener('click', function(){
        attackAllBtn.removeEventListener('click', handleAttackAllClick);
        attackAll(bruteForce, dictionary, [sprayAttack, usernameLabelAttack]);
    });
    attackSingleBtn.addEventListener('click', function(){
        if(usernameField.value != '' && passwordField.value != ''){
            attackSingle(usernameField.value, passwordField.value, attackTable, successAttackLabel);
        }
    });

    restoreTableState(attackTable);
    addUserBtn.addEventListener('click', function(){
        saveTableState(attackTable);
    });

    resetAllBtn.addEventListener('click', function(){
        clearUsers();
        clearAttacks(attackTable);
        localStorage.setItem("attacksQ", 0);
        localStorage.setItem("attackTable", null);
        localStorage.setItem("successAttack", 0);
        attacksQuantity.innerHTML = 0;
        attackListLabel.innerHTML = 0;
        location.reload();
    });
});

function hideUsername(event){
    const inputField = document.querySelector(`input[id='usernameToAttack']`);
    if(event.target.id == sprayAttackId){
        inputField.hidden = false;
    }
    else{
        inputField.hidden = true;
    }
}
/*
Išsaugome lentelės reikšmes
*/
function saveTableState(table) {
    const rows = [];
    table.querySelectorAll("tr").forEach(row => {
        rows.push(row.innerHTML); //Pridedame <td> tag's
    });
    localStorage.setItem("attackTable", JSON.stringify(rows));
}
/*
Atnaujiname reikšmes
*/
function restoreTableState(table){
    const savedRows = JSON.parse(localStorage.getItem("attackTable"));
    if (savedRows) {
        savedRows.forEach(rowHTML => {
            const row = document.createElement("tr");
            row.innerHTML = rowHTML;
            table.appendChild(row);
        });
    }
}

function clearUsers(){
    sendRequest('http://localhost:8080/api/clearUsers', 'POST', []);
}

function clearAttacks(attacksTable){
    while(attacksTable.firstChild){
        attacksTable.removeChild(attacksTable.firstChild)
    }
}

async function sendRequest(requestURL, methodType, bodyValue){
    const data = {}
    
    for(let i = 0; i < bodyValue.length; i+= 2){
        data[bodyValue[i]] = bodyValue[i + 1];
    }
    try{
        const response = await fetch(`${requestURL}`, {
            method: `${methodType}`,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (response.ok) {
            const responseData = await response.json();
            if (responseData.success === true) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    catch(error){
        return error;
    }
}

async function attackSingle(usernameField, passwordField, attackTable, succesAttackLabel){
    const attacksQuantity = document.querySelector(`h1[id='${attacksQId}']`);
    const attackListLabel = document.querySelector(`label[id='${allAttacksLabel}']`);
    var successAttackLabel = document.querySelector(`b[id='${successAttacksLabel}']`);
    const response = await sendRequest("http://localhost:8080/api/attackSingle", method="POST",
        ['username', `${usernameField}`, 'password', `${passwordField}`]);

    const attackedPerson = document.createElement("tr");
    
    attackedPerson.innerHTML = `
        <td>${parseInt(attacksQuantity.innerHTML) + 1}</td>
        <th scope="row">${new Date().toLocaleTimeString()}</th>
        <td>${usernameField}</td>
        <td>${passwordField}</td>
        <td id=${(Boolean(response)) ? `hacked-${parseInt(successAttackLabel.innerHTML) + 1}` : `unhacked-${parseInt(successAttackLabel.innerHTML) + 1}`}
        class=${(Boolean(response)) ? 'bg-success' : 'bg-danger'}></td>`;
    attackedPerson.id = `attacked-person-${parseInt(successAttackLabel.innerHTML) + 1}`;
    attackTable.appendChild(attackedPerson);

    successAttackLabel.innerHTML = (Boolean(response)) ? parseInt(successAttackLabel.innerHTML) + 1 : parseInt(successAttackLabel.innerHTML)
    attacksQuantity.innerHTML = parseInt(attacksQuantity.innerHTML) + 1;
    attackListLabel.innerHTML = attacksQuantity.innerHTML;
    localStorage.setItem("attacksQ", attacksQuantity.innerHTML);
    localStorage.setItem("successAttack", succesAttackLabel.innerHTML);
}

async function attackAll(bruteForce, dictionary, sprayAttack){
    const attackAllBtn = document.querySelector(`button[id*='${attackAllId}']`);
    const timeCounter = document.querySelector(`label[id='timeCounter']`);
    const addUserBtn = document.querySelector(`button[id='addUserBtn']`);
    const singleAttackBtn = document.querySelector(`button[id='attackBtn']`);
    const attackTable = document.querySelector(`tbody[id='${attackTableId}']`);
    const successAttackLabel = document.querySelector(`b[id='${successAttacksLabel}']`);

    attackAllBtn.removeEventListener('click',  handleAttackAllClick);
    let breakLoop = false;
    if(((sprayAttack[0].checked && sprayAttack[1].value != '') || bruteForce.checked || dictionary.checked) && attackAllBtn){

        attackAllBtn.id = `${stopAttackId}`;
        attackAllBtn.classList.remove('btn-primary');
        attackAllBtn.classList.add('btn-danger');
        attackAllBtn.innerHTML = 'STOP ATTACK';

        attackAllBtn.addEventListener('click', function(){
            breakLoop = true;
            stopAttackAllClick();
        });

        //disable other buttons
        addUserBtn.disabled = true;
        singleAttackBtn.disabled = true;
        timeCounter.hidden = false;
        

        //Start counting
        const startCounting = Date.now();
        counterElement = setInterval(() => calculateTime(startCounting, timeCounter), 100);


        let popularPass = await fetch("/scripts/assets/popularPasswords.txt").then(response => {
            if(!response.ok){
                throw new Error("Error by loading file");
            }
            return response.text();
        }).then(text =>{
            return text;
        });

        let popularUsername = await fetch("/scripts/assets/popularUsername.txt").then(response => {
            if(!response.ok){
                throw new Error("Error by loading file");
            }
            return response.text();
        }).then(text =>{
            return text;
        });


        //Making an attack
        if(bruteForce.checked){ //if bruteForce
            const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const numbers = "0123456789";
            const specCharacters = "!@#$%^&*()_+-=[]{}|;:,.<>?";

            const symbols = chars + numbers + specCharacters;
            let usernameLength = 1;
            while(true){
                if(breakLoop || usernameLength == 5){
                    break;
                }
                let results = [];
                let username = getRandomString(usernameLength, symbols, results, "");
                let password = getRandomString(usernameLength, symbols, results, ""); 
                for(let i = 0; i < results.length; i++){
                    await attackSingle(username[i], password[i], attackTable, successAttackLabel);
                }
                usernameLength++;
            }
        }
        else if(dictionary.checked){
            var popularPasswordsList = popularPass.split("\n");
            var popularUsernameList = popularUsername.split("\n");
            for(let i = 0; i < popularPasswordsList.length; i++){
                for(let j = 0; j < popularUsernameList.length; j++){
                    if(breakLoop){break;}
                    else{await attackSingle(popularUsernameList[j].trim(), popularPasswordsList[i].trim(), attackTable, successAttackLabel);}
                }
            }
        }
        else{
            var popularPasswordsList = popularPass.split("\n");
            for(let i = 0; i < popularPasswordsList.length; i++){
                if(breakLoop){break;}
                else{await attackSingle(sprayAttack[1].value.trim(), popularPasswordsList[i].trim(), attackTable, successAttackLabel);}
            }
        }
    }
}

function getRandomString(requiredLength, symbols, results, currentChar){
    console.log(`${requiredLength})\t->\tArray: ${results}\tCurent word:\t${currentChar}`);
    if(currentChar.length === requiredLength){
        results.push(currentChar);
        return;
    }
    for(let char of symbols){
        getRandomString(requiredLength, symbols, results, currentChar + char);
    }
    return results;
}

function stopAttackAll(event){
    clearInterval(counterElement);
    const attackAllBtn = document.querySelector(`button[id*='${stopAttackId}']`); //currently it's stop attack btn
    const timeCounter = document.querySelector(`label[id='timeCounter']`);
    const addUserBtn = document.querySelector(`button[id='addUserBtn']`);
    const singleAttackBtn = document.querySelector(`button[id='attackBtn']`);

    if(attackAllBtn){
        attackAllBtn.removeEventListener('click',  handleAttackAllClick);
        attackAllBtn.id = `${attackAllId}`;
        attackAllBtn.classList.remove('btn-danger');
        attackAllBtn.classList.add('btn-primary');
        attackAllBtn.innerHTML = 'Attack automatically';

        addUserBtn.disabled = false;
        singleAttackBtn.disabled = false;
        timeCounter.hidden = true;

        attackAllBtn.addEventListener('click',  handleAttackAllClick);
    }
    else{
        console.log(`Nerastas id: ${stopAttackId}\tRastas: ${attackAllBtn}`);
    }
}

function handleAttackAllClick() {
    const sprayAttack = document.querySelector(`input[id='${sprayAttackId}']`);
    const bruteForce = document.querySelector(`input[id='${bruteForceId}']`);
    const dictionary = document.querySelector(`input[id='${dictionaryId}']`);
    const usernameLabelAttack = document.querySelector(`input[id='${inputUsernameLabel}']`);

    attackAll(bruteForce, dictionary, [sprayAttack, usernameLabelAttack]);
}

function stopAttackAllClick() {
    stopAttackAll();
}

function calculateTime(startTime, timeCounterElement){
    const time = Date.now();
    timeCounterElement.innerHTML = `Time: <b>${((time - startTime)/1000).toFixed(2)}</b> sec`
}