package password_crack.crack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
